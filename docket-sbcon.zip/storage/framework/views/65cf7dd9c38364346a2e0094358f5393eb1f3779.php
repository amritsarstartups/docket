<?php $__env->startSection('title','Inventory'); ?>

<?php $__env->startSection('content'); ?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Inventory
            <small></small>
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-md-12">
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Details</h3>
               
                </div><!-- /.box-header -->
                <div class="box-body">
                  <?php if(session('success')): ?>
                  <div class="callout callout-success">
                    <h4><i class="icon fa fa-check"></i> <?php echo e(session('success')); ?></h4>
                  </div>
                  <?php endif; ?>
                   <?php if(session('failure')): ?>
                  <div class="callout callout-danger">
                    <h4> <?php echo e(session('failure')); ?></h4>
                  </div>
                  <?php endif; ?>
                  <?php if(count($errors)): ?>
                  <div class="callout callout-danger">
                    <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                      <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </ul>
                  </div>
                  <?php endif; ?>

                  <div class="col-sm-12">
                    <table class="table table-responsive table-striped table-bordered">
                      <tr>
                        <th>Sr. No.</th>
                        <th>Blood Group</th>
                        <th>Quantity</th>
                        <th colspan="3">Actions</th>
                      </tr>
                      <?php 
                        $bgs = array("A+","A-","B+","B-","AB+","AB-","O+","O-");
                        $count=1;
                        $details = App\Detail::where('user_id',\Auth::user()->id)->first();
                       ?>
                      <?php $__currentLoopData = $bgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bg): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <tr>
                          <form method="post">
                            <?php echo e(csrf_field()); ?>

                          <td><?php echo e($count); ?></td>
                          <td><?php echo e($bg); ?></td>
                          <td><?php echo e($details->$bg); ?></td>
                          <input type="hidden" value="<?php echo e($bg); ?>" name="bg">
                          <td><input type="number" class="col-md-4" name="add" placeholder="Add" min="0"></td>
                          <td><input type="number" class="col-md-4" name="sub" placeholder="Sub" min="0"></td>
                          <td><button class="btn btn-primary">Update</button> | </form>
                          <a href="/make_request?bg=<?php echo e($bg); ?>"><button class="btn btn-info">Make Request</button></a></td> 
                        </tr>
                        <?php 
                          $count++;
                         ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </table>
                  </div>
                  <strong>Note: </strong>This is a Beta release, please update single row at a time.
                </div><!-- /.box-body -->
              </div>

          </div>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
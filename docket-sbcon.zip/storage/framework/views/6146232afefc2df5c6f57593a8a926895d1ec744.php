<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!--- My CSS -->
	  <link rel="stylesheet" href="/adminlte/css/custom.css">    
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="/adminlte/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="/adminlte/font-awesome-4.6.3/css/font-awesome.min.css">
    <!-- Ionicons 2.0.0 -->
    <link rel="stylesheet" href="/adminlte/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="/adminlte/dist/css/AdminLTE.min.css">
    
    <link rel="stylesheet" href="/adminlte/dist/css/skins/skin-blue.min.css">

    <link rel="shortcut icon" href="/favicon.png">
    <link rel="stylesheet" href="/adminlte/plugins/datatables/dataTables.bootstrap.css">
    
    <script type="text/javascript" src="/adminlte/js/jquery-2.1.4.min.js"></script>
    <script type="text/javascript" src="/adminlte/js/jquery.validate.min.js"></script>
    <title><?php echo $__env->yieldContent('title'); ?> | Docket</title>
    
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">

      <header class="main-header">

        <!-- Logo -->
        <a href="/" class="logo logo-hide"> <!-- ### logo-hide to hide the logo when screen size less than 767px -->
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><b>Docket</b></span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b>Doc</b>ket</span>
        </a>

        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <!-- Navbar Right Menu -->
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- Messages: style can be found in dropdown.less-->
              
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="/pic2.jpg" class="user-image" alt="User Image">
                  <span class="hidden-xs"><?php echo e(Auth::user()->name); ?></span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
                    <img src="/pic2.jpg" class="img-circle" alt="User Image">
                    <p>
                      <?php echo e(Auth::user()->name); ?>

                      <small>Blood Bank Admin</small>
                    </p>
                  </li>
                  <!-- Menu Body -->
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-left">
                      <a href="/change-password" class="btn btn-default btn-flat">Change Password</a>
                    </div>
                    <div class="pull-right">
                      <a class="btn btn-default btn-flat" onClick="event.preventDefault();
                       document.getElementById('logout-form').submit();">Sign out</a>
                      <form method="post" id="logout-form" action="/logout"><?php echo e(csrf_field()); ?></form>
                    </div>
                  </li>
                </ul>
              </li>
              <!-- Control Sidebar Toggle Button -->
             </ul>
          </div>

        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">
            <div>
              <center><img src="/pic2.jpg" class="img-circle col-xs-12" alt="User Image"></center>
            </div>            
          </div>
          <!-- search form -->
          
          <!-- /.search form -->
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li>
              <a href="/">
                <i class="fa fa-dashboard"></i> Dashboard<span></span>
              </a>
            </li>
            <li>
              <a href="/inventory">
                <i class="fa fa-table"></i> Inventory<span></span>
              </a>
            </li>
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>

      <?php echo $__env->yieldContent('content'); ?>

      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 5.6.17
        </div>
        &copy; Copyright Docket 2017-18. All rights reserved.
      </footer>    
    </div><!-- ./wrapper -->


    <!-- jQuery UI 1.11.4 -->
    <script src="/adminlte/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="/adminlte/bootstrap/js/bootstrap.min.js"></script>

    <script src="/adminlte/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="/adminlte/plugins/datatables/dataTables.bootstrap.min.js"></script>   

    <?php echo $__env->yieldContent('footer_script'); ?>

    <!-- AdminLTE App -->
    <script src="/adminlte/dist/js/app.min.js"></script>
  </body>
</html>

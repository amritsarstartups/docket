<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/','BankController@view_index');
Route::get("/change-password", 'BankController@view_change_password');
Route::post("/change-password", 'BankController@change_password_action');
Route::get('/inventory','BankController@view_inventory');
Route::post('/inventory','BankController@update_inventory');
Route::get('/make_request','BankController@make_request');
Route::post('/','BankController@donate');

Auth::routes();

Route::get('/home', 'HomeController@index');

@extends('layout')

@section('title','Home')

@section('content')
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Dashboard
            <small></small>
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-md-6">
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Blood Donation Window</h3>
               
                </div><!-- /.box-header -->
                <div class="box-body">
                  @if(session('success'))
                  <div class="callout callout-success">
                    <h4><i class="icon fa fa-check"></i> {{session('success')}}</h4>
                  </div>
                  @endif
                  @if(count($errors))
                  <div class="callout callout-danger">
                    <ul>
                      @foreach($errors->all() as $error)
                      <li>{{ $error }}</li>
                      @endforeach
                    </ul>
                  </div>
                  @endif

                  <div class="col-sm-12">
                    <form method="post">
                      {{csrf_field()}}
                      <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">Donar Name</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" placeholder="Enter Name" name="name">
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">Address</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" placeholder="Enter Address" name="address" >
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">Mobile No.</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" placeholder="Enter Mobile No." name="mobile" >
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">Blood Group</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" placeholder="Enter Blood Group" name="bloodgroup">
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">Date of donation</label>
                        <div class="col-sm-9">
                          <input type="date" id="date" class="form-control" name="date" >
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="col-sm-9"><br>
                          <input type="submit" class="btn btn-primary">
                        </div>
                      </div>
                      <script>document.getElementById('date').valueAsDate = new Date();</script> 
          
                  </div>
                </div><!-- /.box-body -->
                </div>
              </div>
            <div class="col-md-6">
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Blood Donation Window</h3>
               
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table class="table table-responsive table-bordered table-striped">
                    <tr>
                      <th>Sr. No.</th>
                      <th>Name</th>
                      <th>Blood Group</th>
                      <th>Phone</th>
                      <th>Address</th>
                      <th>Date</th>
                    </tr>
                    <tr>
                      <td>1</td>
                      <td>Piyush</td>
                      <td>A+</td>
                      <td>9878543235</td>
                      <td>156 street 4, FZR</td>
                      <td>16-06-2017</td>
                    </tr>                    
                    <tr>
                      <td>2</td>
                      <td>Piyush</td>
                      <td>A+</td>
                      <td>9878543235</td>
                      <td>156 street 4, FZR</td>
                      <td>16-06-2017</td>
                    </tr>                    
                    <tr>
                      <td>3</td>
                      <td>Piyush</td>
                      <td>A+</td>
                      <td>9878543235</td>
                      <td>156 street 4, FZR</td>
                      <td>16-06-2017</td>
                    </tr>                    
                    <tr>
                      <td>4</td>
                      <td>Piyush</td>
                      <td>A+</td>
                      <td>9878543235</td>
                      <td>156 street 4, FZR</td>
                      <td>16-06-2017</td>
                    </tr>
                  </table>
                </div><!-- /.box-body -->
                </div>
              </div>

          </div>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->  
@stop


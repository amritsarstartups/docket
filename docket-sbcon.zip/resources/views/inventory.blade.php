@extends('layout')

@section('title','Inventory')

@section('content')
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Inventory
            <small></small>
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-md-12">
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Details</h3>
               
                </div><!-- /.box-header -->
                <div class="box-body">
                  @if(session('success'))
                  <div class="callout callout-success">
                    <h4><i class="icon fa fa-check"></i> {{session('success')}}</h4>
                  </div>
                  @endif
                   @if(session('failure'))
                  <div class="callout callout-danger">
                    <h4> {{session('failure')}}</h4>
                  </div>
                  @endif
                  @if(count($errors))
                  <div class="callout callout-danger">
                    <ul>
                      @foreach($errors->all() as $error)
                      <li>{{ $error }}</li>
                      @endforeach
                    </ul>
                  </div>
                  @endif

                  <div class="col-sm-12">
                    <table class="table table-responsive table-striped table-bordered">
                      <tr>
                        <th>Sr. No.</th>
                        <th>Blood Group</th>
                        <th>Quantity</th>
                        <th colspan="3">Actions</th>
                      </tr>
                      @php
                        $bgs = array("A+","A-","B+","B-","AB+","AB-","O+","O-");
                        $count=1;
                        $details = App\Detail::where('user_id',\Auth::user()->id)->first();
                      @endphp
                      @foreach($bgs as $bg)
                        <tr>
                          <form method="post">
                            {{csrf_field()}}
                          <td>{{$count}}</td>
                          <td>{{$bg}}</td>
                          <td>{{$details->$bg}}</td>
                          <input type="hidden" value="{{$bg}}" name="bg">
                          <td><input type="number" class="col-md-4" name="add" placeholder="Add" min="0"></td>
                          <td><input type="number" class="col-md-4" name="sub" placeholder="Sub" min="0"></td>
                          <td><button class="btn btn-primary">Update</button> | </form>
                          <a href="/make_request?bg={{$bg}}"><button class="btn btn-info">Make Request</button></a></td> 
                        </tr>
                        @php
                          $count++;
                        @endphp
                      @endforeach
                    </table>
                  </div>
                  <strong>Note: </strong>This is a Beta release, please update single row at a time.
                </div><!-- /.box-body -->
              </div>

          </div>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->  
@stop
@extends('layout')

@section('title','Change Password')

@section('content')
<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Change Password
            <small></small>
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
          	<div class="col-xs-12">
          		<div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Change Password</h3>
               
                </div><!-- /.box-header -->
                <div class="box-body">
                	@if(count($errors))
	               	<div class="callout callout-danger">
		                <ul>
		                	@foreach($errors->all() as $error)
		                	<li>{{$error}}</li>
		                	@endforeach
		                </ul>
		            </div>
		            @endif
		
		            @if(session('success'))
						<div class="alert alert-success">
			                <h4><i class="icon fa fa-check"></i>{{ session('success') }}</h4>
			            </div>
					@endif
          		<form class="form-horizontal" method="post" action="">
          			{{csrf_field()}}
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-3 control-label">New Password</label>
                  <div class="col-sm-9">
                    <input type="password" class="form-control" placeholder="New Password" name="newpass" >
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-3 control-label">Confirm Password</label>
                  <div class="col-sm-9">
                    <input type="password" class="form-control" placeholder="Confirm Password" name="newpass_confirmation">
                  </div>
                </div>
                <div class="form-group">
                	<center><button class="btn btn-primary" type="submit">Submit</button></center>
               	</div>
            </form>


            </div>
          	</div>
          </div>
      </section>
  </div>
@stop
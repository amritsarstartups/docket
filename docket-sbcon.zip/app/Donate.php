<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Donate extends Model
{
    protected $table = "donate_requests";
    protected $guarded = ['id','created_at','updated_at'];

    public function client()
    {
        return $this->belongsTo('App\Client');
    }
    
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Detail;
use App\Donation;

class BankController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function donate(Request $request)
    {
        $donation = new Donation($request->all());
        $donation->save();
        return back()->with('success','Entry successful!');
    }

    public function view_index()
    {
    	return view('index');
    }

    public function view_change_password()
    {
    	return view('change-password');
    }

    public function change_password_action(Request $request)
    {
        $this->validate($request, 
            $rules =[
                'newpass'=>'required|confirmed',
                'newpass_confirmation'=>'required'
            ]);

        $user = Auth::user();
          $user->password = bcrypt($request->newpass);
        $user->save();

        return back()->with('success','Password changed successfully!');
    }

    public function view_inventory()
    {
    	return view('inventory');
    }

    public function make_request(Request $request)
    {
    	$user = Auth::user();
    	$bg = urlencode($request->bg);
    	$json = $user->name." is out of ".$bg." blood units, if you are willing please contact: ".$user->address." ,Phone: ".$user->phone;

        // This function sends the request to OneSignal API
        function sendMessage($message,$bg){
		$headings = array(
			"en"=>'Heading'
			);
		$content = array(
			"en" => $message
			);
	
		$fields = array(
			'app_id' => "dfa642dc-2a4e-11e5-be88-bf08920a584e",
			'filters' => array(array("field" => "tag", "key" => "city", "relation" => "=", "value" => Auth::user()->city),array("operator" => "AND"),array("field" => "tag", "key" => "bloodgp", "relation" => "=", "value" => $bg)),
			
			//'included_segments' => array(''),
			'contents' => $content
		);
		
		$fields = json_encode($fields);
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
												   'Authorization: Basic ZGZhNjQzN2MtMmE0ZS0xMWU1LWJlODktZTc0NDgzZjNhYTMx'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

		$response = curl_exec($ch);
		curl_close($ch);
		
		return $response;
	}
                
        $response = sendMessage($json,$bg);

    	return back()->with('success','Your request has been notified!');
    }

    public function update_inventory(Request $request)
    {
    	$bg = $request->bg;
    	$detail = Detail::where('user_id',Auth::user()->id)->first();
    	$detail->$bg = $detail->$bg + $request->add - $request->sub;
    	if($detail->$bg>=0)
    	{
    		$detail->save();
    		return back()->with('success','Inventory updated successfully!');
    	}
    	else
    	{
    		return back()->with('failure','Inventory record cannot be negative!');	
    	}
    }
}
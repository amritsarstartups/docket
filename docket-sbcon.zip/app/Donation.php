<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Donation extends Model
{
    protected $table = "donations";
    protected $guarded = ['id','created_at','updated_at'];

    public function parent()
    {
        return $this->belongsTo('App\User');
    }
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    protected $table = "clients";
    protected $guarded = ['id','created_at','updated_at'];

    public function receives()
    {
        return $this->hasMany('App\Receive');
    }

    public function donates()
    {
        return $this->hasMany('App\Donate');
    }
}

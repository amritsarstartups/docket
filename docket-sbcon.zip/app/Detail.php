<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Detail extends Model
{
    protected $table = "bb_details";
    protected $guarded = ['id','created_at','updated_at'];

    public function parent()
    {
        return $this->belongsTo('App\User');
    }
}
